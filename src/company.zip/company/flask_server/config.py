
#配置基类
class BaseConfig:
    DEBUG = True


config = {
    'default' : BaseConfig
}
