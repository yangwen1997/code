# from flask_server.common import com_reserve
# #
# #
# # # RESULT = com_reserve.find({}).skip(752)
# RESULT = com_reserve.find({})
# # # RESULT = com_reserve.find({"push": "0","tel_check" : "实号", "mark":"知产"}).limit(250)
# # # RESULT = com_reserve.find({}).limit(100).skip(100)
# COUNT = 0
# for _ in RESULT:
# #     # _["mark"] = "资质"
# #     # _["push"] = "0"
# #     # del _["push"]
#     _["tel_check"] = "实号"
#     id = _["_id"]
#     com_reserve.update({"_id":id},_)
# #     COUNT += 1
# print(COUNT)


# import pymongo
#
# DB = pymongo.MongoClient("mongodb://rwuser:48bb67d7996f327b@10.2.1.216:57017,10.2.1.217:57017,10.2.1.218:57017")
# xs_com_reserve = DB['BMD']["Reserve_total"]
#
# DBB = pymongo.MongoClient(host="127.0.0.1",port=27017)
# com_reserve = DBB['BMD']["Reserve_total"]
#
# result = xs_com_reserve.find({})
# com_reserve.insert(result)


import requests
import json
s = requests.session()
s.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36"
})

url = "http://172.16.74.178:8082/captch/captch_touch"
res = s.post(url)
# print(json.loads(res.text()))
print(res.text)
